/**
 * Created by sikharani on 3/2/17.
 */
window.onload = function() {
    checkCookie(); // to check the cookie informtion about the name of the user
    function bgChange(bg) // to change the background dynamically based upon the selected department DHTML
    {
        document.body.background=bg;
    }
    //Started creating the "select-options" dropdown dynamically
    var mainDiv= document.getElementById("mainDiv");
    var newDiv=document.createElement("div");
    mainDiv.appendChild(newDiv);
    var Department=document.createElement("select");
    Department.setAttribute('id','Department');
    newDiv.appendChild(Department);
    var Department=document.getElementById("Department");
//Reading the JSON object "jsondata"
    for(var Dep in jsondata){
        Department.options[Department.options.length]=new Option(Dep,Dep);
    }
//Iteration over the departments
    Department.onchange = function() {
        var s1 = document.getElementById("Department");
        var strUser = s1.options[s1.selectedIndex].text;
        if(strUser=="Electronics")
            bgChange("Electronics.jpg");
        else if(strUser=="Clothing")
            bgChange("Clothing.jpg");
        else
            bgChange("Departments.jpg");
        while (mainDiv.getElementsByTagName('div').length > 1) {
            mainDiv.removeChild(mainDiv.lastChild);

        }
        var newDiv=document.createElement("div");
        mainDiv.appendChild(newDiv);
        var Type=document.createElement("select");
        Type.setAttribute('id','Type');
        newDiv.appendChild(Type);
        var Type=document.getElementById("Type");
        while (mainDiv.getElementsByTagName('div').length > 2) {
            mainDiv.removeChild(mainDiv.lastChild);

        }
        //Iteration over the types of products
        for (var Types in jsondata[this.value]) {
            Type.options[Type.options.length] = new Option(Types,Types);
            console.log(Types);
        }

        Type.onchange = function () {

            while (mainDiv.getElementsByTagName('div').length > 2) {
                mainDiv.removeChild(mainDiv.lastChild);

            }
            reset(); //if the user changes the prodyct type in between after clicking the "finish" button ,it resets the new product information and link
            var newDiv=document.createElement("div");
            mainDiv.appendChild(newDiv);
            var Item=document.createElement("select");
            Item.setAttribute('id','Item');
            newDiv.appendChild(Item);
            var Item=document.getElementById("Item");
            //Iteration over the items
            var Items = jsondata[Department.value][this.value];
            for (var i = 0; i < Items.length; i++) {
                Item.options[Item.options.length] = new Option(Items[i], Items[i]);
            }

            Item.onchange = function () {

                reset(); // if the user changes the item type in between after clicking the "finish" button ,it resets the new product information and link
            };

        };
    };
};
function finish() // when user clicks the finish button display chosen product information and recommend the link
{
    mainDiv= document.getElementById("mainDiv");
    var childCount= document.getElementById('resultDiv').childNodes.length;
    //childCount=child.length;
    console.log(childCount);


    if(childCount ==3)
    {
        alert("Finish button already clicked"); // if the user by mistake double clicks
    }
    else
    {

        var s1 = document.getElementById("Department");
        var strUser = s1.options[s1.selectedIndex].text;
        var t1 = document.createTextNode('You want to buy from: ' + strUser);
        resultDiv.appendChild(t1);
        var s2 = document.getElementById("Type");
        var strUser1 = s2.options[s2.selectedIndex].text;
        var t2 = document.createTextNode(' ' + strUser1);
        resultDiv.appendChild(t2);
        var s3 = document.getElementById("Item");
        var strUser2 = s3.options[s3.selectedIndex].text;
        var t3 = document.createTextNode(' ' + strUser2);
        resultDiv.appendChild(t3);
        childCount= document.getElementById('resultDiv').childNodes.length;

        var t4 = document.createTextNode('Here are some recommendations');
        var a = document.createElement('a');
        a.setAttribute("target", "_blank");
        var linkText = document.createTextNode(" click me ");
        a.appendChild(linkText);
        a.title = " click me";

        if(strUser2=="Iphone")
            a.href = "https://www.amazon.com/s/ref=nb_sb_noss_2?url=search-alias%3Dmobile&field-keywords=iphone";
        else if(strUser2== "Samsung")
            a.href= "https://www.amazon.com/s/ref=nb_sb_noss_2?url=search-alias%3Dmobile&field-keywords=samsung+mobile&rh=n%3A2335752011%2Ck%3Asamsung+mobile";
        else if(strUser2=="Apple")
            a.href="https://www.amazon.com/Gala-Apples-Fresh-Produce-Fruit/dp/B007OC5X40/ref=sr_1_1_s_it?s=grocery&ie=UTF8&qid=1488456736&sr=1-1&keywords=apple";
        else if (strUser2=="Guava")
            a.href="https://www.amazon.com/Fresh-Pink-Flesh-Guava-3lbs/dp/B00BTK21X4/ref=sr_1_1_s_it?s=grocery&ie=UTF8&qid=1488457375&sr=1-1&keywords=guava";
        else if (strUser2=="Potato")
            a.href="https://www.freshdirect.com/srch.jsp?searchParams=potato";
        else if (strUser2=="Tomato")
            a.href="https://www.freshdirect.com/pdp.jsp?productId=veg_pid_2301781&catId=tm";
        else if (strUser2=="Tees")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=Men+tees+shirt&rh=i%3Aaps%2Ck%3AMen+tees+shirt";
        else if (strUser2=="Pants")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=men+pants";
        else if (strUser2=="top")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=women+top&rh=i%3Aaps%2Ck%3Awomen+top";
        else if (strUser2=="jeans")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss_1?url=search-alias%3Daps&field-keywords=women+jeans&rh=i%3Aaps%2Ck%3Awomen+jeans";
        else if (strUser2=="Cereals")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=cereals";
        else if (strUser2=="Pulses")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=pulses&rh=i%3Aaps%2Ck%3Apulses";
        else if (strUser2=="Grains")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=grains&rh=i%3Aaps%2Ck%3Agrains";
        else if( strUser2=="HD")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=HD+TV";
        else if( strUser2=="LCD")
            a.href="https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=lCD+TV&rh=i%3Aaps%2Ck%3AlCD+TV";
        var textDiv= document.getElementById("textDiv");

        textDiv.appendChild(t4);
        textDiv.appendChild(a);
    }
}
function startOver() {
    while (mainDiv.getElementsByTagName('div').length > 1) {
        mainDiv.removeChild(mainDiv.lastChild);

    }
    reset();
}
function reset() {
    var resultDiv = document.getElementById("resultDiv");
    if(resultDiv.childNodes.length>0) {
        while (resultDiv.childNodes.length != 0) {
            resultDiv.removeChild(resultDiv.lastChild);
            //document.getElementById('Div').removeChild(resultDiv.lastChild);
        }
    }
    var textDiv = document.getElementById("textDiv");
    if (textDiv.childNodes.length > 0) {

        textDiv.removeChild(textDiv.firstChild);
        textDiv.removeChild(textDiv.lastChild);
    }
}
//to set the cookies
function setCookie(cookiename, cookievalue, expirydays) {
    var expDate = new Date();
    expDate.setTime(expDate.getTime() + (expirydays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + expDate.toGMTString();
    document.cookie = cookiename + "=" + cookievalue + "; " + expires;
}
// to get the name of the visitor from the stored cookie
function getCookie(cookiename) {
    var name = cookiename + "=";
    var ca = document.cookie.split(';');
    console.log(ca);
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
//to check if the visitor has entered valid information
function checkCookie() {
    var name = getCookie("username");
    if (name != "") {
        alert("Welcome again " + name);
    }
    else {
        alert("Please register first to get offers");
        var myform = document.createElement("myform");
        myform.setAttribute("method", "get");
        var nameinput = document.createElement("input");
        nameinput.setAttribute("id","nameinput");
        nameinput.setAttribute("type", "text");
        nameinput.setAttribute("value", "name");
        var pwinput = document.createElement("input");
        pwinput.setAttribute("id","pwinput");
        pwinput.setAttribute("type", "password");
        pwinput.setAttribute("value", "password");
        var register = document.createElement("button");
        register.setAttribute("text","submit");
        register.setAttribute("type", "submit");
        register.setAttribute("value", "register");
        register.appendChild(document.createTextNode("register"));
        myform.appendChild(nameinput);
        myform.appendChild(pwinput);
        myform.appendChild(register);
        var logindiv=document.getElementById('logindiv');
        logindiv.appendChild(myform);

        register.onclick = function () {
            console.log("botton clicked");
            var n = document.getElementById('nameinput');
            var name=n.value;
            var p = document.getElementById('pwinput');
            var password = p.value;
//validating input information
            if (name == null || name == "") {
                alert("Name can't be blank");
                return false;
            } else if (password.length < 6) {
                alert("Password must be at least 6 characters long.");
                return false;
            }
            setCookie("username", name, 30);
        }
    }
}

